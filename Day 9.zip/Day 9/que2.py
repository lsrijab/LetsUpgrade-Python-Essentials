def count_digit(n):
    count = 0
    while n:
        n //= 10
        count += 1
    return count
def is_armstrong(n):
    if n< 0:
        return False
    number_copy = n
    arm_sum = 0
    digit = count_digit(n)
    while n:
        remainder = n%10
        arm_sum += remainder**digit
        n //= 10
    return arm_sum == number_copy
for i in range(0, 1000+1):
    if is_armstrong(i):
        print(i, end=' ')