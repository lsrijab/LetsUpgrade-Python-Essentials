def is_prime(number):
    for i in range(2, int(number) + 1):
        if number % i == 0:
            return False
    return number
def filter_primes(general_list):
    return set(filter(is_prime, general_list))
list1=range(1,2501)
print(filter_primes(list1))