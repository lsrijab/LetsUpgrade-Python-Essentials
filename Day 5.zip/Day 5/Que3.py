list1=["hey this is sai","i am in mumbai"]
final_list = list(map(lambda x:" ".join([word.capitalize() for word in x.split(" ")]),list1))
print(final_list)