try:
	f=open("que1.txt",'r')
	f.write("My first file\n")
	f.write("This file\n\n")
	f.write("contains three lines\n")
	print("Content is written into the file")
	f.close()
except:
	print("Cannot write into a read only file")
	
