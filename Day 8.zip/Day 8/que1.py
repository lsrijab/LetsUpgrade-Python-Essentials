def my_decorator(f,n):
	def fibonacci(f,n):
		if f==0:
			s=1
		else:
			s=f+1
		if n<=0:
		    print("The requested series is",f)
		else:
		    print(f,s,end=" ")
		    for x in range(2,n):
		        next=f+s                           
		        print(next,end=" ")
		        f=s
		        s=next
	return fibonacci
f=my_decorator(0,10)
print(f(0,10))