import math 
pi = math.pi 
def volume(r, h): 
    return (1 / 3) * pi * r * r * h
def surfacearea(r, h): 
    base=pi*r*r
    side=pi*r*math.sqrt(r*r+h*h)
    return base,side
radius = float(5) 
height = float(12) 
print( "Volume Of Cone : ", volume(radius, height) ) 
print( "Surface Area Of Cone :Base , Side - ", surfacearea(radius, height) )